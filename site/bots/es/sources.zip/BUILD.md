# Reconstruir el cerebro español

Con Python 3, desde esta carpeta:

```sh
python3 tools/import_spanish.py
python3 tools/build_brain.py es
```

No requiere red ni dependencias externas. La salida es `site/bots/es/brain.json`. Este archivo incluye las fuentes del cerebro español y su motor; no es una copia completa del sitio bilingüe. Los comandos de pruebas de docs/ESPANOL.md corresponden al repositorio completo.
